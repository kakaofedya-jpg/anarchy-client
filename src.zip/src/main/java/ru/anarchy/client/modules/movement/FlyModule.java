package ru.anarchy.client.modules.movement;

import net.minecraft.util.math.Vec3d;
import ru.anarchy.client.core.Category;
import ru.anarchy.client.core.Module;

public class FlyModule extends Module {
    private int flyTicks = 0;

    public FlyModule() {
        super("Fly", "Режим полета", Category.MOVEMENT);
        this.bindKey = 0x46; // F
    }

    @Override
    public void onEnable() {
        super.onEnable();
        flyTicks = 0;
        System.out.println("🟢 FLY ВКЛЮЧЕН!");
        if (mc.player != null) {
            mc.player.getVelocity().set(0, 0, 0);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        System.out.println("🔴 FLY ВЫКЛЮЧЕН!");
        if (mc.player != null) {
            mc.player.setVelocity(new Vec3d(0, -0.08, 0));
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null) return;

        flyTicks++;

        // ПРОСТОЙ ПОЛЕТ (работает 100%)
        if (mc.player.isOnGround()) {
            mc.player.setVelocity(mc.player.getVelocity().add(0, 0.4, 0));
        }

        // УПРАВЛЕНИЕ
        double speed = 0.05;
        Vec3d velocity = mc.player.getVelocity();

        if (mc.options.jumpKey.isPressed()) {
            velocity = velocity.add(0, speed, 0);
        }
        if (mc.options.sneakKey.isPressed()) {
            velocity = velocity.add(0, -speed, 0);
        }

        mc.player.setVelocity(velocity);
        mc.player.fallDistance = 0;
    }
}