package ru.anarchy.client.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Менеджер модулей - фасад для управления всеми модулями
 * Реализует паттерн Singleton
 */
public class ModuleManager {
    private static final ModuleManager INSTANCE = new ModuleManager();
    private final List<Module> modules = new ArrayList<>();

    private ModuleManager() {}

    public static ModuleManager getInstance() {
        return INSTANCE;
    }

    /**
     * Регистрация модуля в системе
     */
    public void registerModule(Module module) {
        if (!modules.contains(module)) {
            modules.add(module);
        }
    }

    /**
     * Получение модуля по классу (типизированный доступ)
     */
    @SuppressWarnings("unchecked")
    public <T extends Module> T getModule(Class<T> clazz) {
        for (Module module : modules) {
            if (clazz.isAssignableFrom(module.getClass())) {
                return (T) module;
            }
        }
        return null;
    }

    /**
     * Получение модуля по имени
     */
    public Module getModuleByName(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    /**
     * Обработка нажатия клавиш для биндов
     * Вызывается из основного цикла обработки событий
     */
    public void onKeyPress(int key) {
        for (Module module : modules) {
            if (module.getBindKey() == key) {
                module.toggle();
                break;
            }
        }
    }

    /**
     * Вызов onUpdate() для всех включенных модулей
     * Вызывается каждый тик из главного класса
     */
    public void onUpdate() {
        for (Module module : modules) {
            if (module.isToggled()) {
                try {
                    module.onUpdate();
                } catch (Exception e) {
                    System.err.println("Error in module: " + module.getName());
                    e.printStackTrace();
                }
            }
        }
    }

    public List<Module> getModules() {
        return new ArrayList<>(modules);
    }
}