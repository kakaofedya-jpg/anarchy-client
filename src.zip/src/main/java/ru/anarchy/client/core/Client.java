package ru.anarchy.client.core;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import ru.anarchy.client.modules.movement.FlyModule;

public class Client implements ModInitializer {
    private static final String MOD_NAME = "Arone Client";
    private static final String MOD_VERSION = "1.0.0";

    private KeyBinding flyKey;

    @Override
    public void onInitialize() {
        System.out.println("Arone Client v" + MOD_VERSION + " initialized!");

        // РЕГИСТРИРУЕМ КЛАВИШУ F
        flyKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.arone.fly",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_F,
            "Arone Client"
        ));

        // РЕГИСТРИРУЕМ МОДУЛЬ
        ModuleManager manager = ModuleManager.getInstance();
        manager.registerModule(new FlyModule());

        // ТИК-ОБРАБОТЧИК
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && client.world != null) {
                ModuleManager.getInstance().onUpdate();
            }
            
            // ПРОВЕРЯЕМ НАЖАТИЕ F
            if (flyKey.wasPressed()) {
                FlyModule fly = ModuleManager.getInstance().getModule(FlyModule.class);
                if (fly != null) {
                    fly.toggle();
                    System.out.println("Fly: " + (fly.isToggled() ? "ON" : "OFF"));
                }
            }
        });

        System.out.println("Registered " + manager.getModules().size() + " modules!");
        System.out.println("Press F to toggle Fly!");
    }
}