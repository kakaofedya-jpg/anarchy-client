package ru.anarchy.client.core;

import net.minecraft.client.MinecraftClient;

/**
 * Абстрактный базовый класс для всех модулей
 * Реализует паттерн Template Method для жизненного цикла
 */
public abstract class Module {
    protected final String name;
    protected final String description;
    protected final Category category;
    protected int bindKey;
    protected boolean toggled;
    protected final MinecraftClient mc;

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.bindKey = 0; // По умолчанию без бинда
        this.toggled = false;
        this.mc = MinecraftClient.getInstance();
    }

    /**
     * Вызывается при включении модуля
     * Переопределять для инициализации ресурсов
     */
    public void onEnable() {
        toggled = true;
    }

    /**
     * Вызывается при выключении модуля
     * Переопределять для очистки ресурсов
     */
    public void onDisable() {
        toggled = false;
    }

    /**
     * Вызывается каждый игровой тик (20 раз в секунду)
     * Основной метод для логики модуля
     */
    public abstract void onUpdate();

    /**
     * Переключение состояния модуля
     */
    public void toggle() {
        if (toggled) {
            onDisable();
        } else {
            onEnable();
        }
    }

    // Геттеры и сеттеры
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public int getBindKey() { return bindKey; }
    public void setBindKey(int bindKey) { this.bindKey = bindKey; }
    public boolean isToggled() { return toggled; }
}