package ru.anarchy.client.core;

/**
 * Перечисление категорий для группировки модулей
 */
public enum Category {
    COMBAT,     // Боевые модули (Aura, KillAura)
    MOVEMENT,   // Движение (Speed, Fly, Step)
    RENDER,     // Визуальные (ESP, Fullbright)
    PLAYER,     // Взаимодействие с игроком (NoFall, FastPlace)
    EXPLOIT;    // Эксплойты для анархии (Dupe, Nuker)
}