package ru.anarchy.client.mixins;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.anarchy.client.core.Client;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    
    @Inject(method = "handleKeyEvents", at = @At("HEAD"))
    private void onKeyEvents(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        
        if (client.currentScreen == null && client.player != null) {
            long window = client.getWindow().getHandle();
            
            // ПРОВЕРЯЕМ ВСЕ КЛАВИШИ
            int[] keys = {
                GLFW.GLFW_KEY_F,  // Fly
                GLFW.GLFW_KEY_V,  // Speed (потом)
                GLFW.GLFW_KEY_R,  // KillAura (потом)
                GLFW.GLFW_KEY_N   // NoFall (потом)
            };
            
            for (int key : keys) {
                if (GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS) {
                    Client.getInstance().onKeyPress(key, 0, GLFW.GLFW_PRESS, 0);
                }
            }
        }
    }
}