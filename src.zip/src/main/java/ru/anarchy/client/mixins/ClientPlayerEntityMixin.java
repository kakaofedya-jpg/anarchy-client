package ru.anarchy.client.mixins;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.anarchy.client.core.ModuleManager;
import ru.anarchy.client.modules.movement.FlyModule;

/**
 * Миксин для ClientPlayerEntity - перехват движения
 * Позволяет модифицировать физику игрока
 */
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    /**
     * Перехват метода move() для контроля движения
     * Вызывается перед применением физики
     */
    @Inject(method = "move", at = @At("HEAD"), cancellable = true)
    private void onMove(MovementType movementType, Vec3d movement, CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;

        // Проверяем, включен ли Fly модуль
        FlyModule flyModule = ModuleManager.getInstance().getModule(FlyModule.class);
        if (flyModule != null && flyModule.isToggled()) {
            // Отменяем стандартное движение для полета
            // Используем свою физику через модуль
            ci.cancel();

            // Передаем управление модулю через onUpdate()
            // Но также можно здесь модифицировать движение
            // Например, для плавного управления:
            if (player.input != null) {
                // Дополнительная логика управления полетом
            }
        }
    }

    /**
     * Перехват отправки пакетов движения
     * Для валидации и подмены данных
     */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void onSendMovementPackets(CallbackInfo ci) {
        // Здесь можно модифицировать отправляемые пакеты
        // Например, подмена onGround для обхода античита
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;

        FlyModule flyModule = ModuleManager.getInstance().getModule(FlyModule.class);
        if (flyModule != null && flyModule.isToggled()) {
            // Добавляем флаг onGround = true для NCP
            // (реализация через нативный вызов или отражение)
        }
    }
}